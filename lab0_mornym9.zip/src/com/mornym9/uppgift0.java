package com.mornym9;

public class uppgift0 {
    public static void main(String[] args) {
        System.out.println("Hej Värld!");
    }
}
